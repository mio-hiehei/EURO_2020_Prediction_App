library(tidyverse)

model <- readRDS("model_data.rds")
euro_data <- readRDS("em_teams.rds")

goal_data <- readRDS("match_data.rds")

goal_data <- goal_data[,c("home_score", "away_score", "result")]

goal_data$outcome <- paste0(goal_data$home_score, ":", goal_data$away_score)
