#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {
    
    output_outcome <- reactive({
        
        home_elo <- euro_data$elo[euro_data$team == input$input_home]
        away_elo <- euro_data$elo[euro_data$team == input$input_away]
        
        diff_elo <- home_elo - away_elo
        
        match_outcome <- predict(model, newdat = data.frame(elo_diff_matches = diff_elo), type = "class")
        
        result <- sample(goal_data$outcome[goal_data$result == match_outcome], 1)
        
        result_table <- data.frame(Heim = input$input_home,
                                   Ergebnis = result,
                                   Auswärts = input$input_away)
        
        return(result_table)
        
    })

    output$prediction_table <- renderTable({
        
        output_outcome()
        
    })

})
